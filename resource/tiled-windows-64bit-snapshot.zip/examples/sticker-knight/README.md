Sticker Knight platformer example
---------------------------------

This example is by @ponywolf and released to the public domain. You can
find it at http://opengameart.org/content/sticker-knight-platformer.

It's a great example of using the flexible image collection tilesets with
tiles on object layers, for both the map and the UI.
